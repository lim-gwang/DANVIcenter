$(function(){
    $(".customSlide").slick({
        slidesToShow : 2,
        dots :false,
        // autoplay: true,
        arrows: true,
        // centerMode: true,
        variableWidth: true,
        appendArrows : $(".section3 > .container"),
        responsive: [
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 1,
              }
            }
        ]
    })

    
})
$(function(){
    $(".Related_slide").slick({
        slidesToShow : 5,
        arrows: false,
        dots:false,
        responsive: [
            {
              breakpoint: 1025,
              settings: {
                slidesToShow: 1,
                appendArrows : $(".section4 .Related_figure"),
                arrows: true,
              }
            },
            
        ]
    })
})
