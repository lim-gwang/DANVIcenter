$(function () {
    function getCurrentDevice() {
        var width = window.innerWidth

        if (width > 1024) {
            return 'pc'
        }

        if (width <= 1024) {
            return 'mobile'
        }
    }

    //header gnb menu
    var active = "active"
    var body = $("body")
    var $header = $(".header_top")
    var $headerBtn = $(".header_bt")
    //header 
    $(function() {
        

        //pc header evnet
        $(".depth1")
            .on("mouseenter focusin", function() { 
                    if (window.innerWidth > 1024) {
                        $headerBtn.addClass(active)

                        $(this)
                            .addClass(active)
                            .parent()
                            .addClass(active)
                    }
            })
            .on("mouseleave focusout", function() {
                if (window.innerWidth > 1024) {
                    $headerBtn.removeClass(active)

                    $(this)
                        .removeClass(active)
                        .parent()
                        .removeClass(active)
                }
            })

        // mobile header event
        $(".depth1").on("click", ".depth1_title", function() {
            if (window.innerWidth <= 1024) {
                $(this)
                    .parent()
                    .toggleClass(active)
                    .siblings()
                    .removeClass(active)

                return false
            }
        })

        // HamburgerBtn 
        $(".HamburgerBtn").on("click", function(){
            $("#wrap, body").toggleClass(active)
            $(".depth1").removeClass(active)
        })
    })

    $(function() {
        //haeder scroll fixed
        $("html, body").on("mousewheel DOMmouseScroll", function(e) {
            var e = e.originalEvent        
            
            var delta = e.detail
                ? e.detail * (-100)
                : e.wheelDelta

            if (window.innerWidth < 1024) {
                return
            }

            if (delta > 0) {
                $header.stop().slideUp()
            } else {
                $header.stop().slideDown()
            }
        })
    })

    // sub side menu
    $(function() {
        $(".side_depth > li > a").on("click", function() {
            var depth1 = $(".side_depth")
            var depth2 = $(".side_depth2")

            // .side_depth 에 active 클래스가 없을 시,
            // 클래스를 추가하고 클릭한 a 태그 부모요소인 li태그 클래스 추가 및 그 외 li요소 클래스 제거
            if (depth1.hasClass(active) === false) {
                depth1.addClass(active)
                $(this).parent("li").addClass(active).siblings().removeClass(active)
                return false
            }

            // .side_depth , 클릭한 a태그 부모 요소 li 태그에 둘다 클래스가 있으면 .side_depth 클래스 제거, 
            // 그렇지 않다면 클릭한 a태그 부모 요소 li 태그에 클래스 추가 및 그 외 li요소 클래스 제거
            if ((depth1.hasClass(active) && $(this).parent("li").hasClass(active))) {
                depth1.removeClass(active)
                return false
            } else {
             
               $(this).parent("li").addClass(active).siblings().removeClass(active)
            }
       
            return false
        })
    })

    //popup
    $(function(){
        var popup = $(".popup_layout")

        //popup open
        $(".popup_btn").on("click", function(){
            popup.fadeIn()
            body.css({
                "height": "100vh",
                "overflow" : "hidden"
            })
        })

        //popup close
        $(".popup_close").on("click", function(){
            popup.fadeOut()
            body.css({
                "height": "auto",
                "overflow" : "visible"
            })
        })
    })

    //footer 
    $(function(){
        $(".info").on("click", "button", function() {
            $(this).toggleClass(active)
            $(".infoSite").slideToggle()
        })
    })
})
