//header gnb menu
var active = "active";

//header 
$(function(){

    $(".depth1")
    .on("mouseenter focusin",
         function(){
            $(".header_bt").addClass(active);
            $(this)
            .addClass(active)
            .parent()
            .addClass(active);
        }
    )
    .on("mouseleave focusout",
         function(){
            $(".header_bt").removeClass(active);
            $(this)
            .removeClass(active)
            .parent()
            .removeClass(active);
        }
    );
}) 

//footer 
$(function(){
    $(".info").on("click", "button", function(){
        $(this).toggleClass(active);
        $(".infoSite").slideToggle();
    });

})