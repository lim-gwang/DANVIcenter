$(function(){
    $(".customSlide").slick({
        slidesToShow : 2,
        dots :false,
        // autoplay: true,
        arrows: true,
        // centerMode: true,
        variableWidth: true,
        appendArrows : $(".section3 > .container"),
        // responsive: [
        //     {
        //       breakpoint: 1920,
        //       settings: {
        //         slidesToShow: 4,
        //         arrows: true,
        //         variableWidth: true,
        //       }
        //     }
        // ]
    })

    
})
$(function(){
    $(".Related_slide").slick({
        slidesToShow : 1,
        arrows: false,
        dots:false,
        responsive: [
            {
              breakpoint: 1290,
              settings: {
                slidesToShow: 2,
                variableWidth: true,
                centerMode: true,
                appendArrows : $(".section4 .Related_figure"),
                arrows: true,
                variableWidth: true,
              }
            },
        ]
    })
})
