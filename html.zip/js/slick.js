$(function(){
    $(".customSlide").slick({
        slidesToShow : 2,
        dots :false,
        // autoplay: true,
        arrows: true,
        // centerMode: true,
        variableWidth: true,
        appendArrows : $(".section3 > .container"),
        // responsive: [
        //     {
        //       breakpoint: 1920,
        //       settings: {
        //         slidesToShow: 4,
        //         arrows: true,
        //         variableWidth: true,
        //       }
        //     }
        // ]
    })

})