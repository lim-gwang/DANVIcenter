// animation
$(window).on("load",function(){
    $(function(){
        var active = "active";
        var animation = "animation";
        // 페이지 로딩시 section1 이벤트
       setTimeout(function(){
           $(".section1").addClass(active);
       }, 300);
    
       // section2 scroll event
       var $section2 = $(".section2")[0];
       
    
    //    $(window).on("scroll", function(){
    
    //         var winH = window.innerHeight;
           
    //         var posTop =  $section2.getBoundingClientRect().top;
    //         var absolutePos = scrollY + posTop;
    
    //        console.log($(window).scrollTop(), "scroll")
    //        console.log($section2Effact, "section2")
    //        if($(window).scrollTop() >= $section2Effact ) {
    //            $(".section2").addClass(active);
    //        } else if($(window).scrollTop() < $section2Effact) {
    //            $(".section2").removeClass(active)
    //        }
    //    })
    
    });
    
    // scroll event 
    $(function(){
        var $section;
        var winH;
        var Module = function(){
            $section = document.querySelectorAll("div[class^='section']");
            winH = window.innerHeight;    
            Handler();    
        }
    
        var Handler = function() {
            $(window).on("scroll resize", chackPoint);
        }
    
        var chackPoint = function() {
            for(var i = 0; i < $section.length; i++) {
                var posTop = $section[i].getBoundingClientRect().top;
                if (winH >= posTop) {
                    $section[i].classList.add("active");
                }
            }
        }
    
        Module()
    
    
    });
})

