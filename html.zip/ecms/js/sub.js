$(function(){
  /* xeicon 접근성 */
  $("[class*='xi-']").attr("aria-hidden","true");

  /* faq 아코디언 */
	$(".listFaq .question > a").on("click", function(){
		$(this).parent().parent().toggleClass("active").siblings().removeClass("active");
		return false;
	});

  /* layer */
  $(".schedule_layer .close").on("click", function(){
    $(this).parent().fadeOut();
  });

  /* 댓글 열기 */
  $("div.CommentWrap div.commentList ul li .btn-recomment").on("click", function(){
    $(this).parent().toggleClass("active");
    return false;
  });

});
